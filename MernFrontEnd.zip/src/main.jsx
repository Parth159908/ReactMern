import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css';
import Home from './Components/Home/Home.jsx';
import History from './Components/History/Histroy.jsx';
import LikedVideos from './Components/LikedVideos/LikedVideos.jsx';
import Collections from './Components/Collections/Collections.jsx';
import MyContent from './Components/MyContnent/MyContent.jsx';
import Subscribers from './Components/Subscribers/Subscribers.jsx';
import Settings from './Components/Settings/Settings.jsx';
import Support from './Components/Support/Support.jsx';
import { Route, createBrowserRouter, RouterProvider, createRoutesFromElements } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from "./app/store.js"
import Login from './Components/Login&SignUp/Login.jsx';
import ContextProvider from './hooks/ContexProvider/ContexProvider.jsx';

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path='/' element={<App />}>
      <Route path='/' element={<Home />} />
      <Route path='/history' element={<History />} />
      <Route path='/likedVideos' element={<LikedVideos />} />
      <Route path='/collection' element={< Collections />} />
      <Route path='/myContent' element={< MyContent />} />
      <Route path='/subscribers' element={< Subscribers />} />
      <Route path='/support' element={< Support />} />
      <Route path='/settings' element={< Settings />} />
      <Route path='/login' element={<Login />} />
    </Route>
  )
);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <ContextProvider>
        <RouterProvider router={router} />
      </ContextProvider>
    </Provider>
  </React.StrictMode>,
)
