import * as React from 'react';
// import Home from './Components/Home/Home';
import Header from './Components/Header/Header';
import LeftMenu from './Components/LeftNavigation/LeftMenu';
import { Outlet } from 'react-router-dom';
import {useLocation} from 'react-router-dom';

function App() {
  const location = useLocation();

  const isLoginRoute = location.pathname === '/login';

  return (
    <React.Fragment>
        {!isLoginRoute && <Header />}
        <div className='flex'> 
        {!isLoginRoute && <LeftMenu />}
        <Outlet />
        </div>
        
    </React.Fragment>
  )
}

export default App
