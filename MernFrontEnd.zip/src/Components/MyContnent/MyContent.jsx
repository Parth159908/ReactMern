import React from 'react'

function MyContent() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-red-500'>MyContent component</h1>
    </div>
  )
}

export default MyContent
