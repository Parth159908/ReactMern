import React from 'react'

function Subscribers() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-yellow-500'>Subs component</h1>
    </div>
  )
}

export default Subscribers
