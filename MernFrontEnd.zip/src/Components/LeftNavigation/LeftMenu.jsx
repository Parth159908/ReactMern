import * as React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import '../../assets/commonStyle.scss'
import { HomeIcon, HistoryIcon, LikeIcon, SettingIcon, SubscribeIcon, VideoCameraIcon, SupportIcon, OptionIcon, ContentIcon } from '../../assets/svgIcons';
function LeftMenu() {
  const [isExpanded, setIsExpanded] = React.useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsExpanded(!isExpanded);
  }
  return (
    <div className={`${isExpanded ? 'w-48' : 'w-14'}`}>
      <div className={`bg-custom flex flex-col justify-between calc-hight`}>
        <button onClick={toggleMenu} className="text-white focus:outline-none p-4">
          <OptionIcon />
        </button>
        <ul className='flex-grow'>
          <li className="cursor-pointer flex items-center">
            <NavLink to='/' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent ${isActive ? "text-lime-500" : "text-white"}`}title={!isExpanded?'Home':""}>
              {isExpanded === true ? (
                <>
                  <HomeIcon color='#fff' />
                  Home
                </>
              ) : (
                location.pathname === "/" ? <HomeIcon color='#84cc16' /> : <HomeIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/likedVideos' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'Liked Videos':""}>

              {isExpanded === true ? (
                <>
                  <LikeIcon color='#fff' />
                  Liked Videos
                </>
              ) : (
                location.pathname === "/likedVideos" ? <LikeIcon color='#84cc16' /> : <LikeIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/history' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'History':""}>

              {isExpanded === true ? (
                <>
                  <HistoryIcon color='#fff' />
                  History
                </>
              ) : (
                location.pathname === "/history" ? <HistoryIcon color='#84cc16' /> : <HistoryIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/myContent' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'My Content':""}>

              {isExpanded === true ? (
                <>
                  <VideoCameraIcon color='#fff' />
                  My Content
                </>
              ) : (
                location.pathname === "/myContent" ? <VideoCameraIcon color='#84cc16' /> : <VideoCameraIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/collection' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'Collections':""}>

              {isExpanded === true ? (
                <>
                  <ContentIcon color='#fff' />
                  Collections
                </>
              ) : (
                location.pathname === "/collection" ? <ContentIcon color='#84cc16' /> : <ContentIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/subscribers' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'Subscribers':""}>

              {isExpanded === true ? (
                <>
                  <SubscribeIcon color='#fff' />
                  Subscribers
                </>
              ) : (
                location.pathname === "/subscribers" ? <SubscribeIcon color='#84cc16' /> : <SubscribeIcon color='#fff' />
              )}
            </NavLink>
          </li>
        </ul>
        <ul className='flex-grow'>
          <li className=" cursor-pointer flex items-center">
            <NavLink to='/support' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent  ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'Support':""}>

              {isExpanded === true ? (
                <>
                  <SupportIcon color='#fff' />
                  Support
                </>
              ) : (
                location.pathname === "/support" ? <SupportIcon color='#84cc16' /> : <SupportIcon color='#fff' />
              )}
            </NavLink>
          </li>
          <li className="cursor-pointer flex items-center">
            <NavLink to='/settings' className={({ isActive }) => `p-4 flex w-full border-gray-100 hover:bg-gray-700 lg:hover bg:transparent ${isActive ? "text-lime-500" : "text-white"}`} title={!isExpanded?'setting':""}>

              {isExpanded === true ? (
                <>
                  <SettingIcon color='#fff' />
                  setting
                </>
              ) : (
                location.pathname === "/settings" ? <SettingIcon color='#84cc16' /> : <SettingIcon color='#fff' />
              )}
            </NavLink>
          </li>
        </ul>
      </div>
    </div>
  )
}

export default LeftMenu
