import React from 'react'

function Settings() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-sky-400'>Seetings component</h1>
    </div>
  )
}

export default Settings
