import React from 'react'

function Support() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-white'>support component</h1>
    </div>
  )
}

export default Support
