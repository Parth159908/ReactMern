import React from 'react'

function Collections() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-purple-500'>collection component</h1>
    </div>
  )
}

export default Collections
