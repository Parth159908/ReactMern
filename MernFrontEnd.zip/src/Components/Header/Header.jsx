import React from 'react'
import { Logo } from '../../assets/svgIcons';
import { Link } from 'react-router-dom';
import { SearchIcon } from '../../assets/svgIcons';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { LogOut } from '../../assets/svgIcons';
import { logOutUser } from '../../services/userServices/userServices.js';
import { Context } from '../../hooks/ContexProvider/ContexProvider';
import {ModelPopUp} from '../../hooks/CommonControls/ModelPopUp';

function Header() {

  const navigate = useNavigate();
  const user = useSelector((state) => state.logInLogout.user);
  const [isRightPopUp, setRightPopUp] = React.useState(false);
  const accessToken = useSelector((state) => state.logInLogout.accessToken);
  const { startSpinner, stopSpinner,showMessageBar } = React.useContext(Context);

  const filterButtonClicked = () => {
    console.log('filter api call here ');
  }

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      filterButtonClicked();
    }
  };
  const handleLogin = () => {
    console.log('login api call here ');
    navigate('/login');
  }
  // const handelSignIn = () => {
  //   console.log('login api call here ');
  // }
  const handelAvtarClick = () => {
    console.log('avtart button click');
    setRightPopUp(!isRightPopUp);
  }
  const updateAccountDetails = () =>{
    console.log('update account details');
  }

  const handelLogOut = async () => {
    console.log("accessToken", accessToken);
    startSpinner();
    const response = await logOutUser(accessToken);
    if (response.statusCode === 200 && response.data && response.success) {
      stopSpinner();
      showMessageBar(response.message, 'success')
    navigate('/login');
    }
    else {
      console.log("register failed", response);
      stopSpinner();
      showMessageBar(response.data.message || 'Login failed', 'error');
    }
  }
  return (
    <div className='h-14 bg-custom flex'>
      <div className='flex'>
        <Link to='/'>
          <Logo />
        </Link>
      </div>
      <div className='ml-5 flex justify-center w-1/2 md:w-full pt-4 h-[50px]'>
        <div className='border-2 border-white flex bg-white rounded-lg'>
          <input
            type="text"
            className="w-[500px] h-7 pl-4 focus:outline-none"
            placeholder='Search'
            onKeyDown={handleKeyPress}
          />
          <div className='mt-1'>
            <button onClick={filterButtonClicked}>
              <SearchIcon color={'black'} />
            </button>
          </div>
        </div>
      </div>
      <div className='headerButton'>
        {user ? (
          <div className='avtarImage'>
            <button onClick={handelAvtarClick}>
              <img
                src={user.avtar}
                alt="UserAvatar"
                className='userAvtar'
              />
            </button>
          </div>
        ) : (
          <button onClick={handleLogin} className='button' disabled={user ? true : false}>Login</button>
        )}
        {
          isRightPopUp ? (
            <div className='rightPopUp'>
              <div className='userNameDisplay'>
                <h3>{user?.email}</h3>
              </div>
              <div className='rigtpopImage'>
                <img
                  src={user.avtar}
                  alt="UserAvatar"
                  className='rightPopupImage'
                />
              </div>
              <div className='userNameDisplay'>
                <h3>Hi,{user?.fullName}!</h3>
              </div>
              <div className='rightPopupButton'>
                <button onClick={updateAccountDetails}>Update your Account Details</button>
              </div>
              <hr className='separator' />

              <div className='logOutButton'>
                <LogOut color='#fff' />
                <button onClick={handelLogOut}>Sign-Out</button>
              </div>
            </div>
          ) : ("")
        }
      </div>
      <ModelPopUp
        
      >
        <div>
          hello model pop up 
        </div>
      </ModelPopUp>


    </div>
  )
}

export default Header
