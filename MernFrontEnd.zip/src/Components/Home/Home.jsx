import React from 'react'

import { useSelector } from 'react-redux';
function Home() {
  const user = useSelector((state) => state.logInLogout.user);
  // const accessToken = useSelector((state) => state.logInLogout.accessToken);


  return (
    <div className='flex justify-center items-center w-full'>
      <h1 className='text-white'>Hello {user?.fullName}</h1>
    </div>
  )
}

export default Home
