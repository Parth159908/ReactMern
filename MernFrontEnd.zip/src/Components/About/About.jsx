import React from 'react'

function About() {
  return (
    <div className='flex justify-center items-center w-full'>
      <h1 className='text-orange'> this is aboutus component</h1>
    </div>
  )
}

export default About
