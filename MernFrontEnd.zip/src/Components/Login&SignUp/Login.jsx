import * as React from 'react';
import { LogInLogo} from '../../assets/svgIcons';
import { loginUser,rgisterNewUser } from '../../services/userServices/userServices.js';
import { login } from '../../fetures/loginSlice/loginSlice';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Context } from '../../hooks/ContexProvider/ContexProvider';
import { objectToFormData } from '../../helper/helper.js';
import "../../assets/commonStyle.scss";


function Login({isEditeForm}) {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [loginFormData, setLogInFormData] = React.useState({});
  const [isLoginForm, setIsLogInForm] = React.useState(true);
  const { startSpinner, stopSpinner,showMessageBar } = React.useContext(Context);
  const [signUpFormData, setSignUpFormData] = React.useState({});

  const logInuser = async () => {
    startSpinner();
    const response = await loginUser(loginFormData);
    if (response.statusCode === 200 && response.data && response.success) {

      const { user, accessToken, refreshToken } = response.data;

      dispatch(login({ user, accessToken, refreshToken }));
      stopSpinner();
      // showMessageBar(response.message,MessageBarType.success);
      showMessageBar(response.message, 'success')
      navigate('/');
    }
    else {
      console.log("login failed", response);
      stopSpinner();
      // showMessageBar(response.data.message,MessageBarType.error);
      showMessageBar(response.data.message || 'Login failed', 'error');
    }
  }

  const registerUserCall = async (formData) =>{
    startSpinner();
    const response = await rgisterNewUser(formData);
    if (response.statusCode === 200 && response.data && response.success) {
      stopSpinner();
      showMessageBar(response.message, 'success')
      setIsLogInForm(true);
    }
    else {
      console.log("register failed", response);
      stopSpinner();
      showMessageBar(response.data.message || 'Login failed', 'error'); 
    }
  }

  const handelFormChange = (name, value) => {
    setLogInFormData({
      ...loginFormData,
      [name]: value
    })
  }
  const handelSignUpFormChange = (name, value) => {
    setSignUpFormData({
      ...signUpFormData,
      [name]: value
    });
  }
  const handelFileChange = (name, e) => {
    setSignUpFormData({ ...signUpFormData, [name]: e.target.files[0] })
  }
  const handleLoginClick = () => {
    setIsLogInForm(true);
  }
  const handeleSignClick = () => {
    setIsLogInForm(false);
  }
  const registerUser = () => {
   const formData = objectToFormData(signUpFormData);
   registerUserCall(formData);
  }
  return (
    <React.Fragment>
      <div className='flex justify-center items-center h-screen'>
        {/* <UserIcon />
            <Password /> */}

        <div className="loginForm">
          {/* <div className="background">
            <div className="shape"></div>
            <div className="shape"></div>
          </div> */}
          <div className='formnew'>
            <div className='logInFormLogo'>
              <LogInLogo />
            </div>

            <div className='logInSinupFormButton'>
              <button className={`buttonLogIn ${isLoginForm ? 'active' : ''}`} onClick={handleLoginClick}>LogIn</button>
              <button className={`buttonSignUp ${!isLoginForm ? 'active' : ''}`} onClick={handeleSignClick}>SignUp</button>
            </div>
            <div>
              {
                isLoginForm && !isEditeForm?
                  <div>
                    <label>Username</label>
                    <input type="text" placeholder="Email or Username" id="username" name='userName' onChange={(e) => handelFormChange('userName', e.target.value)} />

                    <label>Password</label>
                    <input type="password" placeholder="Password" id="password" name='password' onChange={(e) => handelFormChange('password', e.target.value)} />

                    <button onClick={logInuser} className='buttonnew'>Log In</button>
                  </div>
                  :
                  <>
                    <div className='singUpForm'>
                      <label>Full Name</label>
                      <input type="text" placeholder="Full Name" id="fullName" name='fullName' onChange={(e) => handelSignUpFormChange('fullName', e.target.value)} />

                      <label>Email</label>
                      <input type="text" placeholder="Email" id="email" name='email' onChange={(e) => handelSignUpFormChange('email', e.target.value)} />

                      <label>Password</label>
                      <input type="password" placeholder="Password" id="password" name='password' onChange={(e) => handelSignUpFormChange('password', e.target.value)} />

                      <label>Username</label>
                      <input type="text" placeholder="Username" id="username" name='userName' onChange={(e) => handelSignUpFormChange('userName', e.target.value)} />
                      <div>
                        <label>Avtar</label>
                        <input type="file" placeholder="Avtar" id="avtar" name='avtar' onChange={(e) => handelFileChange('avtar', e)} />
                        <label>Cover Image</label>
                        <input type="file" placeholder="coverImage" id="coverImage" name='coverImage' onChange={(e) => handelFileChange('coverImage', e)} />
                      </div>
                    </div>
                    <button onClick={registerUser} className='buttonnew'>Sign Up</button>

                  </>
              }

            </div>
          </div>

        </div>
      </div>

    </React.Fragment>
  )
}

export default Login
