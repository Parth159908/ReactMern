import React from 'react'

function LikedVideos() {
  return (
    <div className='flex justify-center items-center w-full'>
        <h1 className='text-green-500'>LikedVideos component</h1>
    </div>
  )
}

export default LikedVideos
