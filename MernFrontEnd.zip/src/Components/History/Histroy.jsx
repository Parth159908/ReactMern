import * as React from 'react'
import { useSelector } from 'react-redux';

function Histroy() {
  const user = useSelector((userData) => userData.logInLogout.user);
  return (
    <React.Fragment>
        <div className='flex justify-center items-center w-full text-center text-orange-700'> {user?.fullName} you are in history tab</div>
    </React.Fragment>
  )
}

export default Histroy
