import { configureStore } from "@reduxjs/toolkit";
import logInLogoutReducer from "../fetures/loginSlice/loginSlice.js"

export const store = configureStore({
    reducer: {
            logInLogout: logInLogoutReducer,
        }
});