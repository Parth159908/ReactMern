import axios from "../../axios/axios.js";

export const loginUser = async (formBody) => {
    
    try {
        const response = await axios.post('/users/login', formBody)
        return response.data;
    } catch (error) {
        const errorMessage = error.response?.data?.message || error.message || 'Unknown Error';
        console.error(errorMessage);
        return error.response;
    }
}
export const logOutUser = async (accessToken) => {
    try {
        const response = await axios.post('/users/logout', {
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                "Content-Type":"multipart/form-data"
            }
        })
        return response.data
    } catch (error) {
        const errorMessage = error.response?.data?.message || error.message || 'Unknown Error';
        console.error(errorMessage);
        return response;
    }
}

export const rgisterNewUser = async (formData) => {
    try {
        const response = await axios.post('/users/register', formData,{
            headers: {
                "Content-Type":"multipart/form-data"
            }
        });
        return response.data;

    }
    catch (error) {
        const errorMessage = error.response?.data?.message || error.message || 'Unknown Error';
        console.error(errorMessage);
        return response;
    }
}