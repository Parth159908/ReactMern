const objectToFormData = (obj) =>{
    const formData = new FormData();
    for (const key in obj) {
        console.log(key, obj[key]); // Log key and value
        // Check if the value is a file object
        if (obj[key] instanceof File) {
            console.log(`${key} is a File object`);
            // If it's a file, append it to FormData
            formData.append(key, obj[key]);
        } else {
            // Otherwise, append as a regular field
            formData.append(key, obj[key]);
        }
    }
    return formData;
}

export {objectToFormData}