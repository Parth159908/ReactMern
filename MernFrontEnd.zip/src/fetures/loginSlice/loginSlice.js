import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    user: null,
    accessToken: '',
    refreshToken: '',
    isAuthenticated: false,
  };

  export const logInLogoutSlice = createSlice({
    name: 'logInLogout',
    initialState,
    reducers: {
      login: (state, action) => {
        state.user = action.payload.user;
        state.accessToken = action.payload.accessToken;
        state.refreshToken = action.payload.refreshToken;
        state.isAuthenticated = true;
      },
      logout: (state) => {
        state.user = null;
        state.accessToken = '';
        state.refreshToken = '';
        state.isAuthenticated = false;
      },
      logInPostApi:(state) =>{
        state.userName = action.payload.userName;
        state.password = action.payload.password;
      }
    },
  });

  export const { login, logout } = logInLogoutSlice.actions;
  export default logInLogoutSlice.reducer;