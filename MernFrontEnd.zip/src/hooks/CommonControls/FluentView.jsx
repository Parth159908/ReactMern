import * as React from 'react'
import { Label } from '@fluentui/react';

const FluentView = (props)=> {
    const { children, labelName, isRequired } = props;

    return (
      <div>
        <div>
          {labelName !== "" && (
            <Label >
              {isRequired && <span>*</span>}
              {labelName}
            </Label>
          )}
          <div>{children}</div>
        </div>
      </div>
    );
}
export default FluentView;
