import React from "react";
import { SearchBox } from "@fluentui/react";
import FluentView from "./FluentView";

const FluentSearchBox = (props) => {
  return (
    <FluentView isRequired={false} labelName={""}>
      <SearchBox className="w-96 bg-white"  
      styles={{
        iconContainer: {
          // Apply Tailwind CSS classes to target the icon container
          color: "black", // Set color to black
        },
        icon: {
          // Apply Tailwind CSS classes to target the icon itself
          color: "black", // Set color to black
        },
        clearButton: {
          // Apply Tailwind CSS classes to target the clear button
          color: "black", // Set color to black
        },
      }}
      {...props} />
    </FluentView>
  );
};

export default FluentSearchBox;
