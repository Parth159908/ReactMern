import React from "react";
import { TextField } from "@fluentui/react";
import FluentView from "./FluentView";

const TextField = (props) => {
  const { labelName, isRequired, ...rest } = props;
  return (
    <FluentView isRequired={isRequired} labelName={labelName}>
      <TextField {...rest} />
    </FluentView>
  );
};

export default TextField;
