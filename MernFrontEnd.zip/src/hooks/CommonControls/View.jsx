import * as React from 'react'
import { Label } from '@fluentui/react';

const View = (props)=> {
    const { children, labelName, isRequired } = props;

    return (
      <div>
        <div>
          {labelName !== "" && (
            <Label >
              {isRequired && <span>*</span>}
              {labelName}
            </Label>
          )}
          <div>{children}</div>
        </div>
      </div>
    );
}
export default View;
