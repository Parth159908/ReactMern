import React from 'react';
import { Modal, IconButton, getTheme, mergeStyleSets, FontWeights } from '@fluentui/react';

const CloseIcon = { iconName: 'Cancel' };

const ModalPopUp = ({ setOpenDialog, hasCloseIcon, handleClose, handleClosed, title, children }) => {
    const contentStyles = mergeStyleSets({
        container: {
            display: 'flex',
            flexFlow: 'column nowrap',
            alignItems: 'stretch',
        },
        header: [
            {
                flex: '1 1 auto',
                borderTop: `4px solid orange`,
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                fontWeight: bold,
                padding: '12px 12px 14px 24px',
            },
        ],
        heading: {
            color: '#fff',
            fontWeight: 'bold',
            fontSize: 'inherit',
            margin: '0',
        }
    });
    const iconButtonStyles = {
        root: {
            color: '#fff',
            marginLeft: 'auto',
            marginTop: '4px',
            marginRight: '2px',
        },
        rootHovered: {
            color:'#000',
        },
    };

    return (
        <React.Fragment>
            <Modal
                isOpen={setOpenDialog}
                onDismiss={handleClose}
                isBlocking={true}
                onDismissed={handleClosed}
            >
                <div className={contentStyles.header}>
                    <h2 className={contentStyles.heading}>
                        {title}
                    </h2>
                    {hasCloseIcon && (
                        <IconButton
                            styles={iconButtonStyles}
                            iconProps={CloseIcon}
                            ariaLabel="Close popup modal"
                            onClick={handleClose} 
                        />
                    )}
                </div>
                {children}
            </Modal>
        </React.Fragment>
    )
}

export default ModalPopUp;
