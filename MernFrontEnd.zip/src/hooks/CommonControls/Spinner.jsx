import * as React from 'react';
import { RotatingLines } from 'react-loader-spinner';


const Spinner = ({ isVisible }) => {
    // const gradientBackground = 'linear-gradient(307deg, rgba(78, 109, 219, 1) 0%, rgba(229, 78, 163, 1) 45%);';
    return (
        <div className={isVisible ? 'overlay' : 'hidden'}>
            <div className='spinnerContainer'>
                <RotatingLines 
                     height={50}
                     width={45}
                     color="#fff"
                     ariaLabel="grid-loading"
                     radius={12.5}
                     wrapperStyle={{}}
                     wrapperClass=""
                     visible={isVisible}
                />
            </div>
        </div>
    )
}

export default Spinner
