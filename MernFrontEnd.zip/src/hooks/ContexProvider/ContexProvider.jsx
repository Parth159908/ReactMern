import * as React from 'react';
import Spinner from '../CommonControls/Spinner';
import { MessageBar, MessageBarType } from '@fluentui/react';
// import '~office-ui-fabric-core/dist/sass/Fabric.scss'
import { Bounce, Slide, ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const Context = React.createContext({
    startSpinner: () => {
        console.log("Starting spinner...");
    },
    stopSpinner: () => {
        console.log("Stop spinner...");
    },
    showMessageBar: (message, type) => { },
    hideMessageBar: () => { },
});

const ContextProvider = ({ children }) => {

    const [isSpinnerVisble, setSpinnerVisible] = React.useState(false);
    const [messageDetail, setMessageDetail] = React.useState(null);

    const handelStartSpinner = () => {
        setSpinnerVisible(true);
    }
    const handelStopSpinner = () => {
        setSpinnerVisible(false);
    }
    const hideMessageBar = () => {
        setMessageDetail(null);
    }
     const showMessageBar = (message, type) => {
        console.log("message", message);
        console.log("type", type);
        switch (type) {
            case 'success':
                toast.success(message, {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                    transition: Slide,
                });
                break;
            case 'error':
                toast.error(message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                    transition: Slide,
                });
                break;
            case 'warning':
                toast.warning(message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                    transition: Slide,
                });
                break;
            default:
                toast.info(message, {
                    position: "top-right",
                    autoClose: 3000,
                    hideProgressBar: true,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",
                    transition: Slide,
                });
        }
    };
    return (
        <React.Fragment>
            <Context.Provider value={{
                startSpinner: handelStartSpinner,
                stopSpinner: handelStopSpinner,
                showMessageBar,
                hideMessageBar,
            }}>
                <ToastContainer
                    position="top-right"
                    autoClose={3000}
                    hideProgressBar
                    newestOnTop={false}
                    closeOnClick
                    rtl={false}
                    pauseOnFocusLoss
                    draggable
                    pauseOnHover
                    theme="dark"
                    transition={Slide}
                />
                <Spinner isVisible={isSpinnerVisble} />
                {children}
            </Context.Provider>
        </React.Fragment >
    )
}
export default ContextProvider